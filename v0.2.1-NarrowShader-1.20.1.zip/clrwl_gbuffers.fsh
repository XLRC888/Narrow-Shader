#version 330 compatibility

uniform sampler2D texture;
uniform sampler2D lightmap;

varying vec4 color;
varying vec2 texcoord;
varying vec2 lmcoord;
varying vec3 normal;
varying vec3 viewPos;

#include "/lib/common.glsl"

/* RENDERTARGETS: 0,1,2 */
layout(location = 0) out vec4 fragColor;
layout(location = 1) out vec4 lightData;
layout(location = 2) out vec4 encodedNormal;

void main() {
    vec4 albedo = texture2D(texture, texcoord) * color;
    if (albedo.a < 0.1) discard;
    vec4 light = texture2D(lightmap, lmcoord);
    vec3 lAlbedo = toLinear(albedo.rgb);
    vec3 lLight = toLinear(light.rgb);
    fragColor = vec4(lAlbedo * lLight, albedo.a);
    lightData = vec4(lmcoord, 0.0, 1.0);
    encodedNormal = vec4(normal * 0.5 + 0.5, 1.0);
}
